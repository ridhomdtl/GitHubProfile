package com.example.githubprofile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubprofile.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: UserViewModel
    private lateinit var adapter: UserProfileAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = UserProfileAdapter()
        adapter.notifyDataSetChanged()

        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(UserViewModel::class.java)

        binding.apply {
            rvProfile.layoutManager = LinearLayoutManager(this@MainActivity)
            rvProfile.setHasFixedSize(true)
            rvProfile.adapter = adapter

            btnSearchbar.setOnClickListener{
                userSearch()
            }
            etSearch.setOnKeyListener { v, keyCode, event ->
                if(event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER){
                    return@setOnKeyListener true
                }
                return@setOnKeyListener false
            }


        }

        viewModel.getSearchUser().observe(this, {
            if (it!=null) {
                adapter.setList(it)
                loadingBar(false)
            }
        })

    }

    private fun userSearch(){
        binding.apply {
            val query = etSearch.text.toString()
            if (query.isEmpty()) return
            loadingBar(true)
            viewModel.setSearchUsers(query)
        }
    }

    private fun loadingBar(state: Boolean){
        if(state){
            binding.progressBar.visibility = View.VISIBLE
        }else{
            binding.progressBar.visibility = View.GONE
        }
    }

}