package com.example.githubprofile

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserViewModel : ViewModel() {

    val userList = MutableLiveData<ArrayList<UserInfo>>()

    fun setSearchUsers(query: String){
        RetrofitClient.apiInstance
            .getSearchUsers(query)
            .enqueue(object : Callback<UserDataClass>{
                override fun onResponse(
                    call: Call<UserDataClass>,
                    response: Response<UserDataClass>
                ) {
                    if(response.isSuccessful){
                        userList.postValue(response.body()?.items)
                    }
                }

                override fun onFailure(call: Call<UserDataClass>, t: Throwable) {
                    t.message?.let { Log.d( "Failure", it ) }
                }

            })
    }

    fun getSearchUser(): LiveData<ArrayList<UserInfo>>{
        return userList
    }

}