package com.example.githubprofile

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface API {
    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getSearchUsers(
        @Query("q") query: String
    ): Call<UserDataClass>
}