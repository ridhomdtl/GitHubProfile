package com.example.githubprofile

data class UserInfo(
    val login: String,
    val avatar_url: String
)
